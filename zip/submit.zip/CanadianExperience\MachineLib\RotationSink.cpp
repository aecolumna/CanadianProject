/**
 * \file RotationSink.cpp
 *
 * \author Andres Columna
 */


#include "stdafx.h"
#include "RotationSink.h"


/**
 * Constructor
 */
CRotationSink::CRotationSink()
{
}

/**
 * Destructor
 */
CRotationSink::~CRotationSink()
{
}
